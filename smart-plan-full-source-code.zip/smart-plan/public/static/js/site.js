// ready function
$(document).ready(function () {
  
  tablePlanning();
  EmployeesTable();

  $("#importBoxEmployeesbtn").click(function () {
    $("#importBoxEmployees").toggleClass("hide");
  });
  $("#toggle_sidebar").click(function (e) {
    $("#default-drawer").toggleClass("hide");
  });

  $("#excelSubmit").click(function (e) {
    upload(e);
  });

  $("form#updateperiod").on("submit", function (e) {
    e.preventDefault();
    UpdatePeriod();
  });

  $("#refreshemp").click(function () {
    EmployeesTable();
  });

  $("#refreshplan").click(function () {
    tablePlanning();
  });

  $("#employeeTableBody,#tablebody,#newemptablebody").on(
    "keypress",
    function (e) {
      if (e.which == 13) {
        e.preventDefault();
        $(e.target).trigger("blur");
        $(e.target).next("td").trigger("focus");
      }
    }
  );

  // $(".datechange").keypress(function (e) {
  //   console.log("yoo");
  //   if (isNaN(String.fromCharCode(e.which))) e.preventDefault();
  // });

  // $("#entrydatepicker").click(function () {
  //   console.log("Inside");
  //   $("#entrydatepicker").datepicker();
  // });

  // specifying datatable plugin to tables
  // $("#predictedyeartable").DataTable({
  //   searching: false,
  //   paging: false,
  //   info: false,
  //   bSort: false,
  // });
  // $("#actualyeartable").DataTable({
  //   scrollX: true,
  //   searching: false,
  //   paging: false,
  //   info: false,
  // });
  // $("#fulllengthtable").DataTable({
  //   scrollX: true,
  //   searching: false,
  //   paging: false,
  //   info: false,
  //   sorting: false,
  // });
  // $("#table").DataTable({
  //   scrollX: true,
  //   searching: false,
  //   paging: false,
  //   info: false,
  //   sorting: false,
  // });
  // $("#toppredictedyeartable").DataTable({
  //   scrollX: true,
  //   searching: false,
  //   paging: false,
  //   info: false,
  // });
  // $("#employeetable").DataTable({
  //   scrollX: true,
  //   searching: false,
  //   paging: false,
  //   info: false,
  //   ordering: false,
  // });
});

// csrftoken for POST request using ajax
var user = "{{request.user}}";
function getToken(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      // Does this cookie string begin with the name we want?
      if (cookie.substring(0, name.length + 1) === name + "=") {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}
const csrftoken = getToken("csrftoken");

// date picker
// function entrydatepicker(id){
//   // $("#myeditablediv").keypress(function(e) {
//     // if (isNaN(String.fromCharCode(e.which))) e.preventDefault();
// // });
//   $("#entrydatepicker"+id+"").datepicker();
//   $("#entrydatepicker"+id+"").datepicker('show');
//   console.log('ok')
// }

// uploading excel file to save data to database
function upload(event) {
  event.preventDefault();
  var file = document.getElementById("file");
  var data = new FormData();
  data.append("file", $('input[id="file"]')[0].files[0]);
  if (file.files.length == 0) {
    console.log("No file selected");
  } else {
    $("#load").removeClass("hide");
    console.log(data);
    $.ajax({
      url: "/upload/",
      type: "POST",
      headers: {
        "X-CSRFToken": csrftoken,
      },
      data: data,
      cache: false,
      processData: false,
      contentType: false,
      mimeType: "multipart/form-data",
      success: function (data) {
        $("#file").val(null);
        EmployeesTable();
      },
    });
  }
  return false;
}

// updating planning main table on every single cell change
function updatetable(thiscell, rowname, id, tablename) {
  var value = thiscell.innerText;

  url = "/api/update/planning/";
  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": csrftoken,
    },
    body: JSON.stringify({
      value: value,
      id: id,
      cellname: rowname,
      tablename: tablename,
    }),
  }).then((data) => {
    // tablePlanning();
  });
}

//onchange set period and time on frontend
function onChangePeriodAndTime() {
  var currentyear = $("#currentyear").val();
  var actualmonth = $("#actualmonth").val();
  var workingdaysinyear = $("#workingdaysinyear").val();
  var hoursperday = $("#hoursperday").val();

  if (parseInt(currentyear) < 1900) {
    $("#currentyear").val(1900);
    currentyear = "1900";
  }

  if (parseInt(hoursperday) < 1) {
    $("#hoursperday").val(1);
    hoursperday = "1";
  }

  if (parseInt(workingdaysinyear) > 365) {
    $("#workingdaysinyear").val(365);
    workingdaysinyear = "365";
  } else if (parseInt(workingdaysinyear) < 1) {
    $("#workingdaysinyear").val(1);
    workingdaysinyear = "1";
  }

  if (parseInt(actualmonth) > 12) {
    $("#actualmonth").val(12);
    actualmonth = "12";
  } else if (parseInt(actualmonth) < 1) {
    $("#actualmonth").val(1);
    actualmonth = "1";
  }

  var firstForcastedMonth = parseInt(actualmonth) + 1;
  var hoursperyear =
    parseInt(workingdaysinyear) * parseInt(hoursperday).toString();

  var hourspermonth = parseInt(hoursperyear) / 12;
  var nextYear = parseInt(currentyear) + 1;
  hourspermonth = hourspermonth.toFixed(1).toString();

  hoursperyear = hoursperyear.toString().replace(/\B(?=(\d{3})+(?!\d))/g, "'");

  if (parseInt(actualmonth) >= 12) {
    firstForcastedMonth = 1;
  }

  $("#firstForcastedMonth").html(firstForcastedMonth);
  $("#heureParAnne").html(hoursperyear);
  $("#heureParMois").html(hourspermonth);
  $("#nextYear").html(nextYear);
}

// updating employee table on every single cell change
function updateEmployeeTable(thiscell, rowname, id) {
  if (thiscell == "empgender") {
    var value = $("#empgender" + id + " option:selected").val();
  } else if (thiscell == "entrydate" || thiscell == "exitdate") {
    var value = $("#" + thiscell + id).val();
  } else {
    // var value = $(thiscell.target).text()
    var value = thiscell.innerText;
  }
  var nametd = $("#empname" + id).text();
  var firstnametd = $("#empfirstname" + id).text();
  employee = nametd + " " + firstnametd;
  // }
  url = "/api/update/employee/";
  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": csrftoken,
    },
    body: JSON.stringify({
      value: value,
      id: id,
      cellname: rowname,
      employee: employee,
    }),
  }).then((data) => {
    if (thiscell == "empgender") {
      EmployeesTable();
    }
  });
}

// updating new employee table on every single cell change
function updateNewEmployeeTable(thiscell, rowname, id) {
  if (thiscell == "gender") {
    var value = $("#gender" + id + " option:selected").val();
    // console.log("Gender", value);
  } else if (thiscell == "newentrydate" || thiscell == "newexitdate") {
    var value = $("#" + thiscell + id).val();
  } else {
    var value = thiscell.innerText;
    // console.log("Not Gender");
  }

  // var employee = "";
  // if (rowname == "name" || rowname == "firstname") {
  var nametd = $("#newname" + id).text();
  var firstnametd = $("#newfirstname" + id).text();
  var employee = nametd + " " + firstnametd;
  // }
  url = "/api/update/new/employees/";
  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": csrftoken,
    },
    body: JSON.stringify({
      value: value,
      id: id,
      cellname: rowname,
      tablename: "NewEmployee",
      employee: employee,
    }),
  }).then((data) => {
    // tablePlanning();
  });
}

function delEmp(id) {
  url = "/api/delete/employee/";
  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": csrftoken,
    },
    body: JSON.stringify({
      id: id,
    }),
  }).then((data) => {
    console.log("Deleted");
    EmployeesTable();
  });
}

// allowing only percent and numbers
var percents = function (e) {
  if ((e.which > 47 && e.which < 58)) {
    return true;
  } else {
    e.preventDefault();
  }
};

// maximum 100%
var percentvalidater = function (e, thiss, id, rowname,table) {
  var value = $(e.target).text().toString();

  if (value.includes("%")) {
    value = value.split("%")[0];
    // $(e.target).html(parseInt(value)+'%')
    if (parseInt(value) >= 100) {
      $(e.target).html("100%");
    } else {
      $(e.target).html(parseInt(value) + "%");
    }
  } else {
    if (parseInt(value) >= 100) {
      $(e.target).html("100%");
    } else {
      $(e.target).html(value.toString() + "%");
    }
  }
  
  if (value == '%' || value == '0' || value==''){
    $(e.target).html("0%");
  }

  if (table=='new'){
    updateNewEmployeeTable(thiss, rowname, id)
  }
  else if(table == 'PredictedYear' || table == 'ActualYear'){
    updatetable(thiss,rowname,id,table)
  }
  else{
    updateEmployeeTable(thiss, rowname, id);
  }
};

// number format for commas
var commavalidater = function (e, thiss, id, rowname) {
  var value = $(e.target).text().toString();

  if (value.includes("'")) {
    value = value.split("'");
    value = value.join("");
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    // $(e.target).text(value);

    $(e.target).html(value);
    // $(e.target).blur()
    // $(e.target).focus()
  } else {
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    $(e.target).html(value);
  }

  updateEmployeeTable(thiss, rowname, id);
};

// number format having only numbers and commas
var noAndComma = function (e) {
  if (e.which > 47 && e.which < 58) {
    return true;
  } else {
    e.preventDefault();
  }
};

function checkingDataforNumbers(value) {
  if (value.includes(",")) {
    value = value.split(",");
    value = value.join("");
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    return value;
  }
  return value;
}

//displaying data in tbody
function EmployeesTable() {
  $.ajax({
    url: "/api/show/employees",
    method: "GET",
    success: function (r) {
      $("#employeeTableBody").html("");
      for (var i = 0; i < r.total.length; i++) {
        var yearlysalary = checkingDataforNumbers(r.total[i].yearlysalary);
        var salary13 = checkingDataforNumbers(r.total[i].salary13e);
        var pensionDeducted = checkingDataforNumbers(
          r.total[i].monthlyLLPemployee
        );
        var pensionCost = checkingDataforNumbers(r.total[i].monthlyLLPcompany);
        $("#employeeTableBody").append(
          "<tr id='empenter'>\
            <td onclick='delEmp(" +
            r.total[i].id +
            ")'><i style='color:red; cursor:pointer;' class='material-icons' id='delEmp'>delete</i></td>\
            <td>" +
            r.total[i].id +
            "</td>\
            <td class='bgc right-alignment-td' contenteditable='true' onblur='updateEmployeeTable(this, \"erpnr\"," +
            r.total[i].id +
            ")' >" +
            r.total[i].erpnr +
            "</td>\
            <td>" +
            r.total[i].employee +
            "</td>\
            <td>" +
            r.total[i].type +
            "</td>\
            <td class='bgc' id='empname" +
            r.total[i].id +
            "' contenteditable='true' onblur='updateEmployeeTable(this, \"name\"," +
            r.total[i].id +
            ")' >" +
            r.total[i].name +
            "</td>\
            <td class='bgc' id='empfirstname" +
            r.total[i].id +
            "' contenteditable='true' onblur='updateEmployeeTable(this, \"firstname\"," +
            r.total[i].id +
            ")' >" +
            r.total[i].firstname +
            "</td>\
            <td style='text-align: center;'>\
            <select class='bgc' style='outline:none; border:hidden;' id='empgender" +
            r.total[i].id +
            '\' onchange=\'updateEmployeeTable("empgender", "gendertype", ' +
            r.total[i].id +
            ")'>\
              <option value='1'>1</option>\
              <option value='2'>2</option>\
            </select>\
            </td>\
            <td>" +
            r.total[i].gender +
            "</td>\
            <td class='bgc' contenteditable='true' onblur='updateEmployeeTable(this, \"department\"," +
            r.total[i].id +
            ")' >" +
            r.total[i].department +
            "</td>\
            <td class='bgc right-alignment-td'> \
            <input class='dateinput bgc' type='date' id='entrydate" +
            r.total[i].id +
            "' placeholder=''\
            value='' onblur='updateEmployeeTable(\"entrydate\", \"entrydate\"," +
            r.total[i].id +
            ")'>\
            </td>\
            <td class='bgc right-alignment-td'> \
            <input class='dateinput bgc' type='date' id='exitdate" +
            r.total[i].id +
            "' placeholder=''\
            value='' onblur='updateEmployeeTable(\"exitdate\", \"exitdate\"," +
            r.total[i].id +
            ")'>\
            </td>\
            <td onkeypress='return percents(event)' class='bgc right-alignment-td' contenteditable='true' onblur='return percentvalidater(event,this, " +r.total[i].id +", \"contractrate\")' >" +
            r.total[i].contractrate +
            "</td>\
            <td onkeypress='return noAndComma(event)' class='bgc right-alignment-td' contenteditable='true' onblur='return commavalidater(event,this, " +
            r.total[i].id +
            ',"yearlysalary")\' >' +
            yearlysalary +
            "</td>\
            <td onkeypress='return noAndComma(event)' class='bgc right-alignment-td' contenteditable='true' onblur='return commavalidater(event,this, " +
            r.total[i].id +
            ',"salary13e")\'>' +
            salary13 +
            "</td>\
            <td  onkeypress='return noAndComma(event)' class='bgc right-alignment-td' contenteditable='true' onblur='return commavalidater(event,this, " +
            r.total[i].id +
            ',"monthlyLLPemployee")\'>' +
            pensionDeducted +
            "</td>\
            <td onkeypress='return noAndComma(event)' class='bgc right-alignment-td'contenteditable='true' onblur='return commavalidater(event,this, " +
            r.total[i].id +
            ',"monthlyLLPcompany")\'>' +
            pensionCost +
            "</td>\
          </tr>"
        );
        $("#entrydate" + r.total[i].id).flatpickr({ dateFormat: "d.m.Y" });
        $("#exitdate" + r.total[i].id).flatpickr({ dateFormat: "d.m.Y" });
        $("#entrydate" + r.total[i].id).val(r.total[i].entrydate);
        $("#exitdate" + r.total[i].id).val(r.total[i].exitdate);

        if (r.total[i].gendertype == 1) {
          $("#empgender" + r.total[i].id).val("1");
        } else if (r.total[i].gendertype == 2) {
          $("#empgender" + r.total[i].id).val("2");
        }
      }
      $("#load").addClass("hide");
    },
  });
}

//displaying data in main planning table
function tablePlanning() {
  $.ajax({
    url: "/api/planning/showtable",
    method: "GET",
    success: function (r) {
      $("#tablebody").html("");
      $("#avgyeartablebody").html("");
      $("#newemptablebody").html("");
      $("#actualyear").html(r.period.currentyear);
      $("#predictedyear").html(r.period.nextyear);

      $("#avgyeartablebody").html(
        "<tr style='font-weight: bold;'>\
            <td colspan='7'></td>\
            <td  style='color:black'>Total</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[0] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[1] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[2] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[3] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[4] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[5] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[6] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[7] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[8] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[9] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[10] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualtotal[11] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualtotal[12] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualtotal[13] +
          "</td>\
          <td colspan='2' ></td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[0] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[1] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[2] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[3] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[4] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[5] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[6] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[7] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[8] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[9] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[10] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictedtotal[11] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedtotal[12] +
          "</td>\
          </tr>\
          <tr>\
          <td colspan='7'></td>\
            <td style='color:black'>Actual</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[0] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[1] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[2] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[3] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[4] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[5] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[6] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[7] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[8] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[9] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[10] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualactual[11] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualactual[12] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualactual[13] +
          "</td>\
          <td colspan='2'></td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[0] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[1] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[2] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[3] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[4] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[5] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[6] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[7] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[8] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[9] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[10] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictedactual[11] +
          "</td>\
        <td class='right-alignment-td'>" +
          r.predictedactual[12] +
          "</td>\
          </tr>\
          <tr>\
          <td colspan='7'></td>\
            <td  style='color:black'>New</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[0] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[1] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[2] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[3] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[4] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[5] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[6] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[7] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[8] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[9] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[10] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.actualnew[11] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualnew[12] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.actualnew[13] +
          "</td>\
          <td colspan='2'></td>\
            <td class='right-alignment-td'>" +
          r.predictednew[0] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[1] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[2] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[3] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[4] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[5] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[6] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[7] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[8] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[9] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[10] +
          "</td>\
            <td class='right-alignment-td'>" +
          r.predictednew[11] +
          "</td>\
          <td class='right-alignment-td'>" +
          r.predictednew[12] +
          "</td>\
          </tr>"
      );

      for (var i = 0; i < r.newemployee.length; i++) {
        $("#newemptablebody").append(
          "<tr>\
            <td>" +
            r.newemployee[i].newid +
            "</td>\
            <td>" +
            r.newemployee[i].type +
            "</td>\
            <td style='padding: 5px 5px;' class='bgc' contenteditable='true' onblur='updateNewEmployeeTable(this, \"employee\"," +
            r.newemployee[i].id +
            ")'>" +
            r.newemployee[i].employee +
            "</td>\
            <td style='text-align: center;'>\
            <select class='bgc' style='outline:none; border:hidden;' id='gender" +
            r.newemployee[i].id +
            '\' onchange=\'updateNewEmployeeTable("gender", "gender", ' +
            r.newemployee[i].id +
            ")'>\
              <option value='man'>man</option>\
              <option value='woman'>woman</option>\
            </select>\
            </td>\
            <td class='bgc' contenteditable='true' onblur='updateNewEmployeeTable(this, \"department\"," +
            r.newemployee[i].id +
            ")'>" +
            r.newemployee[i].department +
            "</td>\
            <td class='right-alignment-td'> \
            <input  class='dateinput bgc right-alignment-td' type='date' id='newentrydate" +
            r.newemployee[i].id +
            "' placeholder=''\
            value='' onblur='updateNewEmployeeTable(\"newentrydate\", \"entrydate\"," +
            r.newemployee[i].id +
            ")'>\
            </td>\
            <td class='right-alignment-td'> \
            <input class='dateinput bgc right-alignment-td' type='date' id='newexitdate" +
            r.newemployee[i].id +
            "' placeholder=''\
            value='' onblur='updateNewEmployeeTable(\"newexitdate\", \"exitdate\"," +
            r.newemployee[i].id +
            ")'>\
            </td>\
            <td onblur='return percentvalidater(event,this, " +r.newemployee[i].id +", \"contractrate\", \"new\")' onkeypress='return percents(event)' class='bgc right-alignment-td' contenteditable='true' >" +
            r.newemployee[i].contractrate +
            '</td>\
            <td onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'jan\', 'ActualYear')\">" +
            r.newactualyear[i].jan +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'feb\', 'ActualYear')\">" +
            r.newactualyear[i].feb +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'mar\', 'ActualYear')\">" +
            r.newactualyear[i].mar +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'apr\', 'ActualYear')\">" +
            r.newactualyear[i].apr +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'may\', 'ActualYear')\">" +
            r.newactualyear[i].may +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'jun\', 'ActualYear')\">" +
            r.newactualyear[i].jun +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'jul\', 'ActualYear')\">" +
            r.newactualyear[i].jul +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'aug\', 'ActualYear')\">" +
            r.newactualyear[i].aug +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'sep\', 'ActualYear')\">" +
            r.newactualyear[i].sep +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'oct\', 'ActualYear')\">" +
            r.newactualyear[i].oct +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'nov\', 'ActualYear')\">" +
            r.newactualyear[i].nov +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newactualyear[i].id +",\'dec\', 'ActualYear')\">" +
            r.newactualyear[i].dec +
            "</td>\
            <td onkeypress='return percents(event)' class='right-alignment-td'  style='text-align: center;'>" +
            r.newactualyear[i].avgFTEactual +
            "</td>\
            <td class='right-alignment-td' style='text-align: center;'>" +
            r.newactualyear[i].avgFTEfullyear +
            '</td>\
            <td colspan="2"></td>\
          <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'jan\', 'PredictedYear')\">" +
            r.newpredictedyear[i].jan +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'feb\', 'PredictedYear')\">" +
            r.newpredictedyear[i].feb +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'mar\', 'PredictedYear')\">" +
            r.newpredictedyear[i].mar +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'apr\', 'PredictedYear')\">" +
            r.newpredictedyear[i].apr +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'may\', 'PredictedYear')\">" +
            r.newpredictedyear[i].may +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'jun\', 'PredictedYear')\">" +
            r.newpredictedyear[i].jun +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'jul\', 'PredictedYear')\">" +
            r.newpredictedyear[i].jul +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'aug\', 'PredictedYear')\">" +
            r.newpredictedyear[i].aug +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'sep\', 'PredictedYear')\">" +
            r.newpredictedyear[i].sep +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'oct\', 'PredictedYear')\">" +
            r.newpredictedyear[i].oct +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'nov\', 'PredictedYear')\">" +
            r.newpredictedyear[i].nov +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.newpredictedyear[i].id +",\'dec\', 'PredictedYear')\">" +
            r.newpredictedyear[i].dec +
            "</td>\
            <td class='right-alignment-td'  style='text-align: center;'>" +
            r.newpredictedyear[i].avgFTEfullyear +
            "</td>\
          </tr>"
        );
        $("#newentrydate" + r.newemployee[i].id).flatpickr({
          dateFormat: "d.m.Y",
        });
        $("#newexitdate" + r.newemployee[i].id).flatpickr({
          dateFormat: "d.m.Y",
        });
        $("#newentrydate" + r.newemployee[i].id).val(
          r.newemployee[i].entrydate
        );
        $("#newexitdate" + r.newemployee[i].id).val(r.newemployee[i].exitdate);

        if (r.newemployee[i].gendertype == 1) {
          $("#gender" + r.newemployee[i].id).val("man");
        } else if (r.newemployee[i].gendertype == 2) {
          $("#gender" + r.newemployee[i].id).val("woman");
        }
      }
      for (var i = 0; i < r.employee.length; i++) {
        $("#tablebody").append(
          "<tr>\
            <td>" +
            r.employee[i].id +
            "</td>\
            <td>" +
            r.employee[i].type +
            "</td>\
            <td style='padding: 5px 5px;'>" +
            r.employee[i].employee +
            "</td>\
            <td style=''>" +
            r.employee[i].gender +
            "</td>\
            <td>" +
            r.employee[i].department +
            "</td>\
            <td class='right-alignment-td'  >" +
            r.employee[i].entrydate +
            "</td>\
            <td class='right-alignment-td' >" +
            r.employee[i].exitdate +
            "</td>\
            <td onkeyup='return percentvalidater(event)' class='right-alignment-td' >" +
            r.employee[i].contractrate +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'jan\', 'ActualYear')\">" +
            r.actualyear[i].jan +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'feb\', 'ActualYear')\">" +
            r.actualyear[i].feb +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'mar\', 'ActualYear')\">" +
            r.actualyear[i].mar +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'apr\', 'ActualYear')\">" +
            r.actualyear[i].apr +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'may\', 'ActualYear')\">" +
            r.actualyear[i].may +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'jun\', 'ActualYear')\">" +
            r.actualyear[i].jun +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'jul\', 'ActualYear')\">" +
            r.actualyear[i].jul +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'aug\', 'ActualYear')\">" +
            r.actualyear[i].aug +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'sep\', 'ActualYear')\">" +
            r.actualyear[i].sep +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'oct\', 'ActualYear')\">" +
            r.actualyear[i].oct +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'nov\', 'ActualYear')\">" +
            r.actualyear[i].nov +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.actualyear[i].id +",\'dec\', 'ActualYear')\">" +
            r.actualyear[i].dec +
            "</td>\
            <td class='right-alignment-td'  style='text-align: center;'>" +
            r.actualyear[i].avgFTEactual +
            "</td>\
            <td class='right-alignment-td'  style='text-align: center;'>" +
            r.actualyear[i].avgFTEfullyear +
            '</td>\
            <td colspan="2"></td>\
          <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'jan\', 'PredictedYear')\">" +
            r.predictedyear[i].jan +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'feb\', 'PredictedYear')\">" +
            r.predictedyear[i].feb +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'mar\', 'PredictedYear')\">" +
            r.predictedyear[i].mar +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'apr\', 'PredictedYear')\">" +
            r.predictedyear[i].apr +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'may\', 'PredictedYear')\">" +
            r.predictedyear[i].may +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'jun\', 'PredictedYear')\">" +
            r.predictedyear[i].jun +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'jul\', 'PredictedYear')\">" +
            r.predictedyear[i].jul +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'aug\', 'PredictedYear')\">" +
            r.predictedyear[i].aug +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'sep\', 'PredictedYear')\">" +
            r.predictedyear[i].sep +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'oct\', 'PredictedYear')\">" +
            r.predictedyear[i].oct +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'nov\', 'PredictedYear')\">" +
            r.predictedyear[i].nov +
            '</td>\
            <td  onkeypress="return percents(event)" class="bgc right-alignment-td" contenteditable="true" onblur="return percentvalidater(event,this, ' +r.predictedyear[i].id +",\'dec\', 'PredictedYear')\">" +
            r.predictedyear[i].dec +
            "</td>\
            <td class='right-alignment-td'  style='text-align: center;'>" +
            r.predictedyear[i].avgFTEfullyear +
            "</td>\
          </tr>"
        );
      }
    },
  });
}

//Adding employee to Employee database from employee page
$("form#addEmployee").submit(function (e) {
  e.preventDefault();
  var erpnrInput = $('input[name="erpnr"]').val().trim();
  var nameInput = $('input[name="name"]').val().trim();
  var firstnameInput = $('input[name="firstname"]').val().trim();
  var genderInput = $("#gender option:selected").val();
  var departmentInput = $('input[name="department"]').val().trim();
  var yearlysalaryInput = $('input[name="yearlysalary"]').val();
  var e13salaryInput = $('input[name="e13salary"]').val();
  var llpemployeeInput = $('input[name="llpemployee"]').val();
  var llpcompanyInput = $('input[name="llpcompany"]').val();
  var contractrateInput = $('input[name="contractrate"]').val();
  var entrydateInput = $('input[name="entry"]').val();
  var exitdateInput = $('input[name="exit"]').val();

  if (parseInt(contractrateInput) > 100 ){
    $('#contractrate').val(100)
    contractrateInput = "100"
  }

  if (nameInput && genderInput && contractrateInput) {
    data = {
      table: "employee",
      erpnr: erpnrInput,
      name: nameInput,
      firstname: firstnameInput,
      gender: genderInput,
      department: departmentInput,
      yearlysalary: yearlysalaryInput,
      e13salary: e13salaryInput,
      llpemployee: llpemployeeInput,
      llpcompany: llpcompanyInput,
      contractrate: contractrateInput,
      entrydate: entrydateInput,
      exitdate: exitdateInput,
    };
    url = "/api/add/employee/";
    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrftoken,
      },
      body: JSON.stringify(data),
    }).then((data) => {
      $("#modal-add-employee").modal("toggle");
      $("form#addEmployee").trigger("reset");
      EmployeesTable();
      console.log("Employee Added");
    });
  }
});

//Adding new employee to NewEmployee table in planning tab
$("form#addNewEmployee").submit(function (e) {
  e.preventDefault();
  var erpnrInput = $('input[name="newerpnr"]').val().trim();
  var nameInput = $('input[name="newname"]').val().trim();
  var firstnameInput = $('input[name="newfirstname"]').val().trim();
  var genderInput = $("#newgender option:selected").val();
  var departmentInput = $('input[name="newdepartment"]').val().trim();
  var yearlysalaryInput = $('input[name="newyearlysalary"]').val();
  var e13salaryInput = $('input[name="newe13salary"]').val();
  var llpemployeeInput = $('input[name="newllpemployee"]').val();
  var llpcompanyInput = $('input[name="newllpcompany"]').val();
  var contractrateInput = $('input[name="newcontractrate"]').val();
  var entrydateInput = $('input[name="newentry"]').val();
  var exitdateInput = $('input[name="newexit"]').val();

  if (parseInt(contractrateInput) > 100 ){
    $('#newcontractrate').val(100)
    contractrateInput = "100"
  }
  if (nameInput && genderInput && contractrateInput) {
    data = {
      table: "newemployee",
      erpnr: erpnrInput,
      name: nameInput,
      firstname: firstnameInput,
      gender: genderInput,
      department: departmentInput,
      yearlysalary: yearlysalaryInput,
      e13salary: e13salaryInput,
      llpemployee: llpemployeeInput,
      llpcompany: llpcompanyInput,
      contractrate: contractrateInput,
      entrydate: entrydateInput,
      exitdate: exitdateInput,
    };
    url = "/api/add/employee/";

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrftoken,
      },
      body: JSON.stringify(data),
    }).then((data) => {
      $("#modal-add-new-employee").modal("toggle");
      $("form#addNewEmployee").trigger("reset");
      tablePlanning();
      console.log("New Employee Added");
    });
  }
});
//updating Period and time
function UpdatePeriod() {
  var currentyear = $("#currentyear").val();
  var actualmonth = $("#actualmonth").val();
  var workingdaysinyear = $("#workingdaysinyear").val();
  var hoursperday = $("#hoursperday").val();
  var currency = $("#currency").val();
  var nextYear = $("#nextYear").text();
  var firstForcastedMonth = $("#firstForcastedMonth").text();
  var peryear = $("#heureParAnne").text();
  var permonth = $("#heureParMois").text();
  data = {
    currentyear: currentyear,
    actualmonth: actualmonth,
    workingdaysinyear: workingdaysinyear,
    hoursperday: hoursperday,
    currency: currency,
    nextYear: nextYear,
    firstForcastedMonth: firstForcastedMonth,
    peryear: peryear,
    permonth: permonth,
  };
  console.log(data);
  url = "/api/update/period/";
  if (
    parseInt(workingdaysinyear) > 365 ||
    parseInt(actualmonth) > 12 ||
    workingdaysinyear == "" ||
    hoursperday == "" ||
    currentyear == "" ||
    currency == "" ||
    actualmonth == ""
  ) {
    $("#incorrectdetails").removeClass("hide");
  } else {
    $("#incorrectdetails").addClass("hide");
    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrftoken,
      },
      body: JSON.stringify(data),
    }).then((data) => {
      $("#firstForcastedMonth").html("");
      $("#heureParAnne").html("");
      $("#heureParMois").html("");
      $("#nextYear").html("");
      $("form#updateperiod").trigger("reset");
      $("#currentyear").val("");
      $("#actualmonth").val("");
      $("#workingdaysinyear").val("");
      $("#hoursperday").val("");
      $("#currency").val("");
    });
    window.location.href = "/";
  }
}
