
USE `technoso_erp`;

CREATE TABLE `resources_employee` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `erpnr` varchar(10) DEFAULT NULL,
  `employee` varchar(50) DEFAULT NULL,
  `type` varchar(5) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `entrydate` varchar(20) DEFAULT NULL,
  `exitdate` varchar(20) DEFAULT NULL,
  `yearlysalary` int DEFAULT NULL,
  `salary13e` int DEFAULT NULL,
  `monthlyLLPemployee` int DEFAULT NULL,
  `monthlyLLPcompany` int DEFAULT NULL,
  `contractrate` varchar(10) DEFAULT NULL,
  `gendertype` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 ;

CREATE TABLE `resources_newemployee` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `newid` varchar(10) DEFAULT NULL,
  `erpnr` varchar(10) DEFAULT NULL,
  `employee` varchar(50) DEFAULT NULL,
  `type` varchar(5) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `gendertype` int DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `entrydate` varchar(20) DEFAULT NULL,
  `exitdate` varchar(20) DEFAULT NULL,
  `yearlysalary` int DEFAULT NULL,
  `salary13e` int DEFAULT NULL,
  `monthlyLLPemployee` int DEFAULT NULL,
  `monthlyLLPcompany` int DEFAULT NULL,
  `contractrate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ;


CREATE TABLE `resources_period` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `currentyear` varchar(10) DEFAULT NULL,
  `lastactualmonth` varchar(10) DEFAULT NULL,
  `firstforecastedmonth` varchar(10) DEFAULT NULL,
  `hoursperday` varchar(10) DEFAULT NULL,
  `heureparannee` varchar(10) DEFAULT NULL,
  `heureparmois` varchar(10) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `nextyear` varchar(10) DEFAULT NULL,
  `workingdayinyear` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ;



CREATE TABLE `resources_actualyear` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `year` int DEFAULT NULL,
  `jan` varchar(10) DEFAULT NULL,
  `feb` varchar(10) DEFAULT NULL,
  `mar` varchar(10) DEFAULT NULL,
  `apr` varchar(10) DEFAULT NULL,
  `may` varchar(10) DEFAULT NULL,
  `jun` varchar(10) DEFAULT NULL,
  `jul` varchar(10) DEFAULT NULL,
  `aug` varchar(10) DEFAULT NULL,
  `sep` varchar(10) DEFAULT NULL,
  `oct` varchar(10) DEFAULT NULL,
  `nov` varchar(10) DEFAULT NULL,
  `dec` varchar(10) DEFAULT NULL,
  `avgFTEactual` varchar(10) DEFAULT NULL,
  `avgFTEfullyear` varchar(10) DEFAULT NULL,
  `empid_id` bigint DEFAULT NULL,
  `newempid_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resources_actualyear_newempid_id_98c29cf9_fk_resources` (`newempid_id`),
  KEY `resources_actualyear_empid_id_c498688a_fk_resources_employee_id` (`empid_id`),
  CONSTRAINT `resources_actualyear_empid_id_c498688a_fk_resources_employee_id` FOREIGN KEY (`empid_id`) REFERENCES `resources_employee` (`id`),
  CONSTRAINT `resources_actualyear_newempid_id_98c29cf9_fk_resources` FOREIGN KEY (`newempid_id`) REFERENCES `resources_newemployee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 ;


CREATE TABLE `resources_predictedyear` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `year` int DEFAULT NULL,
  `jan` varchar(10) DEFAULT NULL,
  `feb` varchar(10) DEFAULT NULL,
  `mar` varchar(10) DEFAULT NULL,
  `apr` varchar(10) DEFAULT NULL,
  `may` varchar(10) DEFAULT NULL,
  `jun` varchar(10) DEFAULT NULL,
  `jul` varchar(10) DEFAULT NULL,
  `aug` varchar(10) DEFAULT NULL,
  `sep` varchar(10) DEFAULT NULL,
  `oct` varchar(10) DEFAULT NULL,
  `nov` varchar(10) DEFAULT NULL,
  `dec` varchar(10) DEFAULT NULL,
  `avgFTEfullyear` varchar(10) DEFAULT NULL,
  `empid_id` bigint DEFAULT NULL,
  `newempid_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resources_predictedy_newempid_id_5a4a33e6_fk_resources` (`newempid_id`),
  KEY `resources_predictedy_empid_id_29712867_fk_resources` (`empid_id`),
  CONSTRAINT `resources_predictedy_empid_id_29712867_fk_resources` FOREIGN KEY (`empid_id`) REFERENCES `resources_employee` (`id`),
  CONSTRAINT `resources_predictedy_newempid_id_5a4a33e6_fk_resources` FOREIGN KEY (`newempid_id`) REFERENCES `resources_newemployee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 ;
