from email.policy import default
from django.db import models


class Employee(models.Model):
    erpnr = models.CharField(max_length=10, blank=True, null=True)
    employee = models.CharField(max_length=50, blank=True, null=True)
    type = models.CharField(max_length=7, blank=True,
                            null=True, default='Actual')
    name = models.CharField(max_length=30, blank=True, null=True)
    firstname = models.CharField(max_length=30, blank=True, null=True)
    gendertype = models.IntegerField(blank=True, null=True)
    gender = models.CharField(max_length=10, blank=True, null=True)
    department = models.CharField(max_length=30, blank=True, null=True)
    entrydate = models.CharField(max_length=20, blank=True, null=True)
    exitdate = models.CharField(max_length=20, blank=True, null=True)
    yearlysalary = models.CharField(max_length=20, blank=True, null=True)
    salary13e = models.CharField(max_length=20, blank=True, null=True)
    monthlyLLPemployee = models.CharField(max_length=20, blank=True, null=True)
    monthlyLLPcompany = models.CharField(max_length=20, blank=True, null=True)
    contractrate = models.CharField(max_length=10, blank=True, null=True)

    def __str__(self):
        return self.employee


class NewEmployee(models.Model):
    newid = models.CharField(max_length=10, blank=True, null=True)
    erpnr = models.CharField(max_length=10, blank=True, null=True)
    employee = models.CharField(max_length=50, blank=True, null=True)
    type = models.CharField(max_length=5, blank=True, null=True, default='New')
    name = models.CharField(max_length=30, blank=True, null=True)
    firstname = models.CharField(max_length=30, blank=True, null=True)
    gendertype = models.IntegerField(blank=True, null=True)
    gender = models.CharField(max_length=10, blank=True, null=True)
    department = models.CharField(max_length=30, blank=True, null=True)
    entrydate = models.CharField(max_length=20, blank=True, null=True)
    exitdate = models.CharField(max_length=20, blank=True, null=True)
    yearlysalary = models.CharField(max_length=20, blank=True, null=True)
    salary13e = models.CharField(max_length=20, blank=True, null=True)
    monthlyLLPemployee = models.CharField(max_length=20, blank=True, null=True)
    monthlyLLPcompany = models.CharField(max_length=20, blank=True, null=True)
    contractrate = models.CharField(max_length=10, blank=True, null=True)

    def __str__(self):
        return self.employee


class ActualYear(models.Model):
    empid = models.ForeignKey(
        Employee, on_delete=models.CASCADE, null=True, blank=True)
    newempid = models.ForeignKey(
        NewEmployee, on_delete=models.CASCADE, null=True, blank=True)
    year = models.IntegerField(blank=True, null=True)
    jan = models.CharField(max_length=10, blank=True, null=True, default='0%')
    feb = models.CharField(max_length=10, blank=True, null=True, default='0%')
    mar = models.CharField(max_length=10, blank=True, null=True, default='0%')
    apr = models.CharField(max_length=10, blank=True, null=True, default='0%')
    may = models.CharField(max_length=10, blank=True, null=True, default='0%')
    jun = models.CharField(max_length=10, blank=True, null=True, default='0%')
    jul = models.CharField(max_length=10, blank=True, null=True, default='0%')
    aug = models.CharField(max_length=10, blank=True, null=True, default='0%')
    sep = models.CharField(max_length=10, blank=True, null=True, default='0%')
    oct = models.CharField(max_length=10, blank=True, null=True, default='0%')
    nov = models.CharField(max_length=10, blank=True, null=True, default='0%')
    dec = models.CharField(max_length=10, blank=True, null=True, default='0%')
    avgFTEactual = models.CharField(
        max_length=10, blank=True, null=True, default='0%')
    avgFTEfullyear = models.CharField(
        max_length=10, blank=True, null=True, default='0%')


class PredictedYear(models.Model):
    empid = models.ForeignKey(
        Employee, on_delete=models.CASCADE, null=True, blank=True)
    newempid = models.ForeignKey(
        NewEmployee, on_delete=models.CASCADE, null=True, blank=True)
    year = models.IntegerField(blank=True, null=True)
    jan = models.CharField(max_length=10, blank=True, null=True, default='0%')
    feb = models.CharField(max_length=10, blank=True, null=True, default='0%')
    mar = models.CharField(max_length=10, blank=True, null=True, default='0%')
    apr = models.CharField(max_length=10, blank=True, null=True, default='0%')
    may = models.CharField(max_length=10, blank=True, null=True, default='0%')
    jun = models.CharField(max_length=10, blank=True, null=True, default='0%')
    jul = models.CharField(max_length=10, blank=True, null=True, default='0%')
    aug = models.CharField(max_length=10, blank=True, null=True, default='0%')
    sep = models.CharField(max_length=10, blank=True, null=True, default='0%')
    oct = models.CharField(max_length=10, blank=True, null=True, default='0%')
    nov = models.CharField(max_length=10, blank=True, null=True, default='0%')
    dec = models.CharField(max_length=10, blank=True, null=True, default='0%')
    avgFTEfullyear = models.CharField(
        max_length=10, blank=True, null=True, default='0%')


class Period(models.Model):
    currentyear = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    lastactualmonth = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    firstforecastedmonth = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    workingdayinyear = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    hoursperday = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    heureparannee = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    heureparmois = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    currency = models.CharField(
        max_length=10, blank=True, null=True, default='0')
    nextyear = models.CharField(
        max_length=10, blank=True, null=True, default='0')
