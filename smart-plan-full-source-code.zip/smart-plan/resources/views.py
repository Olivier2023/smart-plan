from http.client import HTTPResponse
import json
import math
from datetime import datetime
from operator import length_hint
from pickletools import long1
from unicodedata import name
from urllib.request import HTTPErrorProcessor
import xlwt
from pathlib import Path
from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render
import mimetypes
from .models import *
from tablib import Dataset
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import *
from django.db import connection


def _checknullperiod(request):
    period = Period.objects.all()
    if not period:
        Period.objects.create(
            currentyear='0'
        )


def delete(request):
    Employee.objects.all().delete()
    NewEmployee.objects.all().delete()
    PredictedYear.objects.all().delete()
    ActualYear.objects.all().delete()
    return HttpResponse('Del')
# main page (employee)


def excel_upload(request):
    if request.method == 'POST':
        dataset = Dataset()
        try:
            excel_file = request.FILES.get("file")
        except:
            return render(request, 'resources/employee.html')

        imported_data = dataset.load(excel_file.read(), format='xlsx')
        period = Period.objects.get(pk=1)
        for data in imported_data:

            if not (data[0] == 'ERP NR' or data[0] == '' or data[0] is None or data[3] == '' or data[3] is None):
                gender = ''
                if str(data[5]) == '1':
                    gender = 'man'
                else:
                    gender = 'woman'

                entryDate = str(str(data[8]).split(' ')[0])
                exitDate = str(str(data[9]).split(' ')[0])
                if not (data[8] == '' or data[8] == 'None' or data[8] is None):
                    entryDate = datetime.strptime(
                        entryDate, '%Y-%m-%d').strftime('%d.%m.%Y')
                if not (data[9] == '' or data[9] == 'None' or data[9] is None):
                    exitDate = datetime.strptime(
                        exitDate, '%Y-%m-%d').strftime('%d.%m.%Y')

                if entryDate == '' or entryDate == 'None' or entryDate is None:
                    entryDate = ''
                if exitDate == '' or exitDate == 'None' or exitDate is None:
                    exitDate = ''

                value = Employee.objects.create(
                    erpnr=data[0],
                    employee=str(data[3])+' '+str(data[4]),
                    type='Actual',
                    name=data[3],
                    firstname=data[4],
                    gendertype=data[5],
                    gender=gender,
                    department=data[7],
                    entrydate=entryDate,
                    exitdate=exitDate,
                    yearlysalary=('{:,}'.format(data[10])),
                    salary13e=('{:,}'.format(data[11])),
                    monthlyLLPemployee=('{:,}'.format(data[12])),
                    monthlyLLPcompany=('{:,}'.format(data[13])),
                    contractrate=str(int(float(data[14])*100))+'%'
                )
                actualyear = ActualYear.objects.create(
                    empid=value,
                    year=period.currentyear
                )
                predictedyear = PredictedYear.objects.create(
                    empid=value,
                    year=period.nextyear
                )

    return HttpResponse('ok')


def index(request):
    return render(request, 'resources/employee.html')


# planning page


def planning(request):
    _checknullperiod(request)
    period = Period.objects.get(pk=1)
    actualmonth = [i for i in range(int(period.lastactualmonth))]
    planmonth = [i for i in range((12-int(period.lastactualmonth)))]
    data = {'actual': actualmonth, 'plan': planmonth}
    return render(request, 'resources/planning.html', data)

# period and time page


def period(request):
    _checknullperiod(request)
    period = Period.objects.get(pk=1)
    data = {'p': period}
    return render(request, 'resources/period.html', data)


# apis
@ api_view(['GET'])
def api_planning(request):
    period = Period.objects.get(pk=1)
    employee = Employee.objects.all()
    newemployee = NewEmployee.objects.all()

    # for i in employee:
    #     actualyear ActualYear.objects.get(year=period.currentyear,empid=id)
    actualyear = ActualYear.objects.filter(year=period.currentyear)
    predictedyear = PredictedYear.objects.filter(year=period.nextyear)

    actualyearlist = []
    predictedyearlist = []
    newactualyearlist = []
    newpredictedyearlist = []

    for i, j in zip(actualyear, predictedyear):
        if i.empid is None or i.empid == '':
            newactualyearlist.append(i)
        else:
            actualyearlist.append(i)
        if j.empid is None or j.empid == '':
            newpredictedyearlist.append(j)
        else:
            predictedyearlist.append(j)

    for i in newactualyearlist:
        print(i.id)
    employeeSerializer = EmployeeSerializer(employee, many=True)
    newemployeeSerializer = NewEmployeeSerializer(newemployee, many=True)
    actualSerializer = ActualYearSerializer(actualyearlist, many=True)
    predictSerializer = PredictedYearSerializer(predictedyearlist, many=True)
    periodSerializer = PeriodSerializer(period)
    newactualSerializer = ActualYearSerializer(newactualyearlist, many=True)
    newpredictSerializer = PredictedYearSerializer(
        newpredictedyearlist, many=True)

    actualYearTable = api_show_actualyear_table(request)
    predictedYearTable = api_show_predictedyear_table(request)

    data = {'employee': employeeSerializer.data,
            'actualyear': actualSerializer.data,
            'predictedyear': predictSerializer.data,
            'newemployee': newemployeeSerializer.data,
            'newactualyear': newactualSerializer.data,
            'newpredictedyear': newpredictSerializer.data,
            'period': periodSerializer.data,
            'actualtotal': actualYearTable['total'],
            'actualactual': actualYearTable['actual'],
            'actualnew': actualYearTable['new'],
            'predictedtotal': predictedYearTable['total'],
            'predictedactual': predictedYearTable['actual'],
            'predictednew': predictedYearTable['new'],
            }
    return Response(data)


def api_update_planning(request):

    data = json.loads(request.body)
    value = data['value']
    id = int(data['id'])
    columnname = data['cellname']
    tablename = data['tablename']

    # cursor = connection.cursor()

    # cursor.execute("UPDATE resources_"+str(tablename)+" SET " +
    #                str(columnname)+" = "+str(value)+" WHERE id = "+str(id)+"")

    if tablename == 'ActualYear':
        obj = ActualYear.objects.get(pk=id)
    elif tablename == 'PredictedYear':
        obj = PredictedYear.objects.get(pk=id)

    if '%' not in value:
        value = str(value) + '%'

    if str(value).split('%')[1]:
        value = str(value).split('%')[0] + '%'

    if columnname == 'jan':
        obj.jan = value
    if columnname == 'feb':
        obj.feb = value
    if columnname == 'mar':
        obj.mar = value
    if columnname == 'apr':
        obj.apr = value
    if columnname == 'may':
        obj.may = value
    if columnname == 'jun':
        obj.jun = value
    if columnname == 'jul':
        obj.jul = value
    if columnname == 'aug':
        obj.aug = value
    if columnname == 'sep':
        obj.sep = value
    if columnname == 'oct':
        obj.oct = value
    if columnname == 'nov':
        obj.nov = value
    if columnname == 'dec':
        obj.dec = value

    obj.save()

    actual = ActualYear.objects.get(pk=id)
    predict = PredictedYear.objects.get(pk=id)
    period = Period.objects.get(pk=1)

    actualmonth = int(period.lastactualmonth)
    months = [actual.jan.split('%')[0], actual.feb.split('%')[0], actual.mar.split('%')[0], actual.apr.split('%')[0], actual.may.split('%')[0], actual.jun.split('%')[0], actual.jul.split('%')[0], actual.aug.split('%')[0],
              actual.sep.split('%')[0], actual.oct.split('%')[0], actual.nov.split('%')[0], actual.dec.split('%')[0]]
    predictmonths = [predict.jan.split('%')[0], predict.feb.split('%')[0], predict.mar.split('%')[0], predict.apr.split('%')[0], predict.may.split('%')[0], predict.jun.split('%')[0], predict.jul.split('%')[0],
                     predict.aug.split('%')[0], predict.sep.split('%')[0], predict.oct.split('%')[0], predict.nov.split('%')[0], predict.dec.split('%')[0]]
    avgFTEcy = 0
    avgFTEactual = 0
    avgFTEny = 0

    for i in range(actualmonth):
        avgFTEactual += int(months[i])

    for i in months:
        avgFTEcy += int(i)

    for i in predictmonths:
        avgFTEny += int(i)

    actual.avgFTEfullyear = str(int(avgFTEcy/12))+'%'
    actual.avgFTEactual = str(int(avgFTEactual/actualmonth))+'%'
    actual.save()
    predict.avgFTEfullyear = str(int(avgFTEny/12))+'%'
    predict.save()
    return HttpResponse('ok')


def api_show_actualyear_table(request):
    period = Period.objects.get(pk=1)
    actualyear = ActualYear.objects.filter(year=period.currentyear)

    asis = ActualYear.objects.filter(
        empid__type='ASIS', year=period.currentyear)
    new = ActualYear.objects.filter(
        newempid__type='New', year=period.currentyear)

    totalFTE = []
    actualFTE = []
    newFTE = []

    jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec, actual, fullyear, year = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    newjan, newfeb, newmar, newapr, newmay, newjun, newjul, newaug, newsep, newoct, newnov, newdec, newactual, newfullyear, newyear = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    asiajan, asiafeb, asiamar, asiaapr, asiamay, asiajun, asiajul, asiaaug, asiasep, asiaoct, asianov, asiadec, asiaactual, asiafullyear, asiayear = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

    for i in actualyear:
        jan += int(i.jan.split('%')[0])
        feb += int(i.feb.split('%')[0])
        mar += int(i.mar.split('%')[0])
        apr += int(i.apr.split('%')[0])
        may += int(i.may.split('%')[0])
        jun += int(i.jun.split('%')[0])
        jul += int(i.jul.split('%')[0])
        aug += int(i.aug.split('%')[0])
        sep += int(i.sep.split('%')[0])
        oct += int(i.oct.split('%')[0])
        nov += int(i.nov.split('%')[0])
        dec += int(i.dec.split('%')[0])
        actual += int(i.avgFTEactual.split('%')[0])
        fullyear += int(i.avgFTEfullyear.split('%')[0])
        year = int(i.year)

    totalFTE.append((jan/100))
    totalFTE.append((feb/100))
    totalFTE.append((mar/100))
    totalFTE.append((apr/100))
    totalFTE.append((may/100))
    totalFTE.append((jun/100))
    totalFTE.append((jul/100))
    totalFTE.append((aug/100))
    totalFTE.append((sep/100))
    totalFTE.append((oct/100))
    totalFTE.append((nov/100))
    totalFTE.append((dec/100))
    totalFTE.append((actual/100))
    totalFTE.append((fullyear/100))
    totalFTE.append(year)

    for i in asis:
        asiajan += int(i.jan.split('%')[0])
        asiafeb += int(i.feb.split('%')[0])
        asiamar += int(i.mar.split('%')[0])
        asiaapr += int(i.apr.split('%')[0])
        asiamay += int(i.may.split('%')[0])
        asiajun += int(i.jun.split('%')[0])
        asiajul += int(i.jul.split('%')[0])
        asiaaug += int(i.aug.split('%')[0])
        asiasep += int(i.sep.split('%')[0])
        asiaoct += int(i.oct.split('%')[0])
        asianov += int(i.nov.split('%')[0])
        asiadec += int(i.dec.split('%')[0])
        asiaactual += int(i.avgFTEactual.split('%')[0])
        asiafullyear += int(i.avgFTEfullyear.split('%')[0])

    actualFTE.append((asiajan/100))
    actualFTE.append((asiafeb/100))
    actualFTE.append((asiamar/100))
    actualFTE.append((asiaapr/100))
    actualFTE.append((asiamay/100))
    actualFTE.append((asiajun/100))
    actualFTE.append((asiajul/100))
    actualFTE.append((asiaaug/100))
    actualFTE.append((asiasep/100))
    actualFTE.append((asiaoct/100))
    actualFTE.append((asianov/100))
    actualFTE.append((asiadec/100))
    actualFTE.append((asiaactual/100))
    actualFTE.append((asiafullyear/100))

    for i in new:
        newjan += int(i.jan.split('%')[0])
        newfeb += int(i.feb.split('%')[0])
        newmar += int(i.mar.split('%')[0])
        newapr += int(i.apr.split('%')[0])
        newmay += int(i.may.split('%')[0])
        newjun += int(i.jun.split('%')[0])
        newjul += int(i.jul.split('%')[0])
        newaug += int(i.aug.split('%')[0])
        newsep += int(i.sep.split('%')[0])
        newoct += int(i.oct.split('%')[0])
        newnov += int(i.nov.split('%')[0])
        newdec += int(i.dec.split('%')[0])
        newactual += int(i.avgFTEactual.split('%')[0])
        newfullyear += int(i.avgFTEfullyear.split('%')[0])

    newFTE.append((newjan/100))
    newFTE.append((newfeb/100))
    newFTE.append((newmar/100))
    newFTE.append((newapr/100))
    newFTE.append((newmay/100))
    newFTE.append((newjun/100))
    newFTE.append((newjul/100))
    newFTE.append((newaug/100))
    newFTE.append((newsep/100))
    newFTE.append((newoct/100))
    newFTE.append((newnov/100))
    newFTE.append((newdec/100))
    newFTE.append((newactual/100))
    newFTE.append((newfullyear/100))

    data = {'total': totalFTE, 'actual': actualFTE, 'new': newFTE}
    return data


def api_show_predictedyear_table(request):
    period = Period.objects.get(pk=1)
    predictedyear = PredictedYear.objects.filter(year=period.nextyear)

    asis = PredictedYear.objects.filter(
        empid__type='ASIS', year=period.nextyear)
    new = PredictedYear.objects.filter(
        newempid__type='New', year=period.nextyear)

    totalFTE = []
    actualFTE = []
    newFTE = []

    jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec, actual, fullyear, year = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    newjan, newfeb, newmar, newapr, newmay, newjun, newjul, newaug, newsep, newoct, newnov, newdec, newactual, newfullyear, newyear = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    asiajan, asiafeb, asiamar, asiaapr, asiamay, asiajun, asiajul, asiaaug, asiasep, asiaoct, asianov, asiadec, asiaactual, asiafullyear, asiayear = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

    for i in predictedyear:
        jan += int(i.jan.split('%')[0])
        feb += int(i.feb.split('%')[0])
        mar += int(i.mar.split('%')[0])
        apr += int(i.apr.split('%')[0])
        may += int(i.may.split('%')[0])
        jun += int(i.jun.split('%')[0])
        jul += int(i.jul.split('%')[0])
        aug += int(i.aug.split('%')[0])
        sep += int(i.sep.split('%')[0])
        oct += int(i.oct.split('%')[0])
        nov += int(i.nov.split('%')[0])
        dec += int(i.dec.split('%')[0])
        fullyear += int(i.avgFTEfullyear.split('%')[0])
        year = int(i.year)

    totalFTE.append((jan/100))
    totalFTE.append((feb/100))
    totalFTE.append((mar/100))
    totalFTE.append((apr/100))
    totalFTE.append((may/100))
    totalFTE.append((jun/100))
    totalFTE.append((jul/100))
    totalFTE.append((aug/100))
    totalFTE.append((sep/100))
    totalFTE.append((oct/100))
    totalFTE.append((nov/100))
    totalFTE.append((dec/100))
    totalFTE.append((fullyear/100))
    totalFTE.append(year)

    for i in asis:
        asiajan += int(i.jan.split('%')[0])
        asiafeb += int(i.feb.split('%')[0])
        asiamar += int(i.mar.split('%')[0])
        asiaapr += int(i.apr.split('%')[0])
        asiamay += int(i.may.split('%')[0])
        asiajun += int(i.jun.split('%')[0])
        asiajul += int(i.jul.split('%')[0])
        asiaaug += int(i.aug.split('%')[0])
        asiasep += int(i.sep.split('%')[0])
        asiaoct += int(i.oct.split('%')[0])
        asianov += int(i.nov.split('%')[0])
        asiadec += int(i.dec.split('%')[0])
        asiafullyear += int(i.avgFTEfullyear.split('%')[0])

    actualFTE.append((asiajan/100))
    actualFTE.append((asiafeb/100))
    actualFTE.append((asiamar/100))
    actualFTE.append((asiaapr/100))
    actualFTE.append((asiamay/100))
    actualFTE.append((asiajun/100))
    actualFTE.append((asiajul/100))
    actualFTE.append((asiaaug/100))
    actualFTE.append((asiasep/100))
    actualFTE.append((asiaoct/100))
    actualFTE.append((asianov/100))
    actualFTE.append((asiadec/100))
    actualFTE.append((asiafullyear/100))

    for i in new:
        newjan += int(i.jan.split('%')[0])
        newfeb += int(i.feb.split('%')[0])
        newmar += int(i.mar.split('%')[0])
        newapr += int(i.apr.split('%')[0])
        newmay += int(i.may.split('%')[0])
        newjun += int(i.jun.split('%')[0])
        newjul += int(i.jul.split('%')[0])
        newaug += int(i.aug.split('%')[0])
        newsep += int(i.sep.split('%')[0])
        newoct += int(i.oct.split('%')[0])
        newnov += int(i.nov.split('%')[0])
        newdec += int(i.dec.split('%')[0])
        newfullyear += int(i.avgFTEfullyear.split('%')[0])

    newFTE.append((newjan/100))
    newFTE.append((newfeb/100))
    newFTE.append((newmar/100))
    newFTE.append((newapr/100))
    newFTE.append((newmay/100))
    newFTE.append((newjun/100))
    newFTE.append((newjul/100))
    newFTE.append((newaug/100))
    newFTE.append((newsep/100))
    newFTE.append((newoct/100))
    newFTE.append((newnov/100))
    newFTE.append((newdec/100))
    newFTE.append((newfullyear/100))

    data = {'total': totalFTE, 'actual': actualFTE, 'new': newFTE}
    return data


def api_update_period(request):

    data = json.loads(request.body)
    currentyear = data['currentyear']
    actualmonth = data['actualmonth']
    workingdaysinyear = data['workingdaysinyear']
    hoursperday = data['hoursperday']
    currency = data['currency']
    nextYear = data['nextYear']
    firstForcastedMonth = data['firstForcastedMonth']
    peryear = data['peryear']
    permonth = data['permonth']
    oldperiod = Period.objects.get(pk=1)

    obj = Period.objects.get(id=1)
    obj.currentyear = str(currentyear).strip()
    obj.lastactualmonth = str(actualmonth).strip()
    obj.firstforecastedmonth = str(firstForcastedMonth).strip()
    obj.workingdayinyear = str(workingdaysinyear).strip()
    obj.hoursperday = str(hoursperday).strip()
    obj.heureparannee = str(peryear).strip()
    obj.heureparmois = str(permonth).strip()
    obj.currency = currency
    obj.nextyear = str(nextYear).strip()
    obj.save()

    if oldperiod.currentyear != obj.currentyear:
        period = Period.objects.get(pk=1)
        employee = Employee.objects.all()
        newemployee = NewEmployee.objects.all()

        for emp in employee:
            actualyear = ActualYear.objects.create(
                empid=emp,
                year=period.currentyear
            )
            predictedyear = PredictedYear.objects.create(
                empid=emp,
                year=period.nextyear
            )

        for newemp in newemployee:
            actualyear = ActualYear.objects.create(
                newempid=newemp,
                year=period.currentyear
            )
            predictedyear = PredictedYear.objects.create(
                newempid=newemp,
                year=period.nextyear
            )
    return HttpResponse('ok')


def api_add_employee(request):
    data = json.loads(request.body)

    tablename = data['table']
    name = data['name']
    erpnr = data['erpnr']
    firstname = data['firstname']
    gender = data['gender']
    department = data['department']
    yearlysalary = data['yearlysalary']
    e13salary = data['e13salary']
    llpemployee = data['llpemployee']
    llpcompany = data['llpcompany']
    contractrate = data['contractrate']
    entrydate = data['entrydate']
    exitdate = data['exitdate']

    gendertype = 0
    if gender == 'man':
        gendertype = 1
    else:
        gendertype = 2

    entryDate = str(entrydate)
    exitDate = str(exitdate)
    try:
        if not (entryDate == '' or entryDate == 'None' or entryDate is None):
            entryDate = datetime.strptime(
                entryDate, '%Y-%m-%d').strftime('%d.%m.%Y')
        if not (exitDate == '' or exitDate == 'None' or exitDate is None):
            exitDate = datetime.strptime(
                exitDate, '%Y-%m-%d').strftime('%d.%m.%Y')
    except:
        pass
    # if entryDate == '' or entryDate == 'None' or entryDate is None:
    #     print('None')
    # if exitDate == '' or exitDate == 'None' or exitDate is None:
    #     print('None')

    period = Period.objects.get(pk=1)
    if tablename == 'employee':
        obj = Employee.objects.create(
            erpnr=erpnr,
            employee=str(name)+' '+str(firstname),
            type='Actual',
            name=name,
            firstname=firstname,
            gendertype=gendertype,
            gender=gender,
            department=department,
            entrydate=str(entryDate),
            exitdate=str(exitDate),
            yearlysalary=('{:,}'.format(int(yearlysalary))),
            salary13e=('{:,}'.format(int(e13salary))),
            monthlyLLPemployee=('{:,}'.format(int(llpemployee))),
            monthlyLLPcompany=('{:,}'.format(int(llpcompany))),
            contractrate=str(int(contractrate))+'%'
        )
        actualyear = ActualYear.objects.create(
            empid=obj,
            year=period.currentyear
        )
        predictedyear = PredictedYear.objects.create(
            empid=obj,
            year=period.nextyear
        )
    elif tablename == 'newemployee':
        obj = NewEmployee.objects.create(
            erpnr=erpnr,
            employee=str(name)+' '+str(firstname),
            name=name,
            firstname=firstname,
            gendertype=gendertype,
            gender=gender,
            department=department,
            entrydate=str(entryDate),
            exitdate=str(exitDate),
            yearlysalary=('{:,}'.format(int(yearlysalary))),
            salary13e=('{:,}'.format(int(e13salary))),
            monthlyLLPemployee=('{:,}'.format(int(llpemployee))),
            monthlyLLPcompany=('{:,}'.format(int(llpcompany))),
            contractrate=str(int(contractrate))+'%'
        )
        new = NewEmployee.objects.get(pk=obj.id)
        new.newid = 'N'+str(obj.id)
        new.save()
        obj = NewEmployee.objects.get(pk=obj.id)
        actualyear = ActualYear.objects.create(
            newempid=obj,
            year=period.currentyear
        )
        predictedyear = PredictedYear.objects.create(
            newempid=obj,
            year=period.nextyear
        )
    else:
        obj = ''

    return HttpResponse('Employee Added Successfully')


def api_delete_employee(request):
    data = json.loads(request.body)
    id = data['id']
    employee = Employee.objects.get(pk=id)
    employee.delete()
    return HttpResponse('Employee Deleted Successfully')


def api_update_employee(request):
    data = json.loads(request.body)
    value = data['value']
    id = data['id']
    columnname = data['cellname']
    employee = data['employee']

    obj = Employee.objects.get(pk=id)

    # if columnname == 'yearlysalary' or columnname == 'salary13e' or columnname == 'monthlyLLPcompany' or columnname == 'monthlyLLPcompany':
    #     if ',' in value:
    #         value = ''.join(str(value).split(','))
    #         value = ('{:,}'.format(int(value)))
    #     elif ',' not in value:
    #         value = ('{:,}'.format(int(value)))

    if columnname == 'erpnr':
        obj.erpnr = value
    if columnname == 'name':
        obj.name = value
        obj.employee = employee
    if columnname == 'firstname':
        obj.firstname = value
        obj.employee = employee
    if columnname == 'gendertype':
        obj.gendertype = int(value)
        if str(value) == '1':
            obj.gender = 'man'
        elif str(value) == '2':
            obj.gender = 'woman'
        else:
            obj.gender = 'undefined'
    if columnname == 'department':
        obj.department = value
    if columnname == 'entrydate':
        obj.entrydate = value
    if columnname == 'exitdate':
        obj.exitdate = value
    if columnname == 'yearlysalary':
        obj.yearlysalary = value
    if columnname == 'salary13e':
        obj.salary13e = value
    if columnname == 'monthlyLLPemployee':
        obj.monthlyLLPemployee = value
    if columnname == 'monthlyLLPcompany':
        obj.monthlyLLPcompany = value
    if columnname == 'contractrate':
        if '%' not in value:
            value = str(value) + '%'
        if str(value).split('%')[1]:
            value = str(value).split('%')[0] + '%'
        obj.contractrate = value
    obj.save()
    return HttpResponse('Employee Updated')


def download_excel_template(request, filename='FCT_Template.xlsx'):
    if filename != '':
        BASE_DIR = Path(__file__).resolve().parent.parent
        filepath = (BASE_DIR / 'static' / filename)
        path = open(filepath, 'rb')
        mime_type, _ = mimetypes.guess_type(filepath)
        response = HttpResponse(path, content_type=mime_type)
        response['Content-Disposition'] = "attachment; filename=%s" % filename
        return response
    else:
        return render(request, 'FCT_Template.xlsx')


@ api_view(['GET'])
def api_show_employees(request):
    employee = Employee.objects.all()
    employeeSerializer = EmployeeSerializer(employee, many=True)
    data = {'total': employeeSerializer.data}
    return Response(data)


def api_update_new_employess(request):

    data = json.loads(request.body)
    value = data['value']
    id = data['id']
    columnname = data['cellname']
    tablename = data['tablename']
    employee = data['employee']

    if columnname == 'yearlysalary' or columnname == 'salary13e' or columnname == 'monthlyLLPcompany' or columnname == 'monthlyLLPcompany':
        if ',' in value:
            value = ''.join(str(value).split(','))
            value = ('{:,}'.format(int(value)))
        elif ',' not in value:
            value = ('{:,}'.format(int(value)))

    if tablename == 'NewEmployee':
        obj = NewEmployee.objects.get(pk=id)
        if columnname == 'gender':
            if value == 'man':
                obj.gender = value
                obj.gendertype = 1
            if value == 'woman':
                obj.gender = value
                obj.gendertype = 2
        if columnname == 'employee':
            obj.employee = value
            name = str(value).split(' ')[0]
            firstname = str(value).split(' ')[1]
            obj.name = name
            obj.firstname = firstname
        if columnname == 'erpnr':
            obj.erpnr = value
        if columnname == 'name':
            obj.name = value
            obj.employee = employee
        if columnname == 'firstname':
            obj.firstname = value
            obj.employee = employee
        if columnname == 'gendertype':
            obj.gendertype = int(value)
            if str(value) == '1':
                obj.gender = 'man'
            elif str(value) == '2':
                obj.gender = 'woman'
            else:
                obj.gender = 'undefined'
        if columnname == 'department':
            obj.department = value
        if columnname == 'entrydate':
            obj.entrydate = value
        if columnname == 'exitdate':
            obj.exitdate = value
        if columnname == 'yearlysalary':
            obj.yearlysalary = int(value)
        if columnname == 'salary13e':
            obj.salary13e = int(value)
        if columnname == 'monthlyLLPemployee':
            obj.monthlyLLPemployee = int(value)
        if columnname == 'monthlyLLPcompany':
            obj.monthlyLLPcompany = int(value)
        if columnname == 'contractrate':
            if '%' not in value:
                value = str(value) + '%'
            if str(value).split('%')[1]:
                value = str(value).split('%')[0] + '%'
            obj.contractrate = value
        obj.save()

    return HttpResponse('ok')


def download_excel_data(request):
    # content-type of response
    response = HttpResponse(content_type='application/ms-excel')

    # decide file name
    response['Content-Disposition'] = 'attachment; filename="FCT-RH-Planning.xls"'

    # creating workbook
    wb = xlwt.Workbook(encoding='utf-8')

    # adding sheet
    ws = wb.add_sheet("FCT-RH")

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    # headers are bold
    font_style.font.bold = True

    # get your data, from database or from a text file...
    period = Period.objects.get(pk=1)
    employee = Employee.objects.all()
    actualyear = ActualYear.objects.filter(year=period.currentyear)
    predictedyear = PredictedYear.objects.filter(year=period.nextyear)
    newemployee = NewEmployee.objects.all()
    print(employee)
    print(actualyear)
    # actualyearfilter = []
    # predictedyearfilter = []

    # for emp, actual, predicted in zip(employee, actualyear, predictedyear):
    #     if emp.id == actual.empid.id:
    #         actualyearfilter.append(actual)
    #     if emp.id == predicted.empid.id:
    #         predictedyearfilter.append(predicted)

    actualyearlist = []
    predictedyearlist = []
    newactualyearlist = []
    newpredictedyearlist = []

    for i, j in zip(actualyear, predictedyear):
        if i.empid is None or i.empid == '':
            newactualyearlist.append(i)
        else:
            actualyearlist.append(i)
        if j.empid is None or j.empid == '':
            newpredictedyearlist.append(j)
        else:
            predictedyearlist.append(j)

    # column header names, you can use your own headers here
    columns = ['ID #', 'ERP NR', 'Employee', 'Type', 'Name', 'First Name', 'Gender Type (1:man, 2:woman)', 'Gender', 'Department', 'Entry date', 'Exit date', 'Yearly salary for 100% (w/o 13th)', '13e Salary for 100%',
               'Monthly LLP employee for 100%', 'Monthly LLP company for 100%', 'Contract Rate', '1.0', '2.0', '3.0', '4.0', '5.0', '6.0', '7.0', '8.0', '9.0', '10.0', '11.0', '12.0', 'AVG FTE Actual', 'AVG FTE Full year', '1.0', '2.0', '3.0', '4.0', '5.0', '6.0', '7.0', '8.0', '9.0', '10.0', '11.0', '12.0', 'AVG FTE Full year', ]

    ws.write(row_num, 16, period.currentyear, font_style)
    ws.write(row_num, 17, period.currentyear, font_style)
    ws.write(row_num, 18, period.currentyear, font_style)
    ws.write(row_num, 19, period.currentyear, font_style)
    ws.write(row_num, 20, period.currentyear, font_style)
    ws.write(row_num, 21, period.currentyear, font_style)
    ws.write(row_num, 22, period.currentyear, font_style)
    ws.write(row_num, 23, period.currentyear, font_style)
    ws.write(row_num, 24, period.currentyear, font_style)
    ws.write(row_num, 25, period.currentyear, font_style)
    ws.write(row_num, 26, period.currentyear, font_style)
    ws.write(row_num, 27, period.currentyear, font_style)
    ws.write(row_num, 28, period.currentyear, font_style)
    ws.write(row_num, 29, period.currentyear, font_style)
    ws.write(row_num, 30, period.nextyear, font_style)
    ws.write(row_num, 31, period.nextyear, font_style)
    ws.write(row_num, 32, period.nextyear, font_style)
    ws.write(row_num, 33, period.nextyear, font_style)
    ws.write(row_num, 34, period.nextyear, font_style)
    ws.write(row_num, 35, period.nextyear, font_style)
    ws.write(row_num, 36, period.nextyear, font_style)
    ws.write(row_num, 37, period.nextyear, font_style)
    ws.write(row_num, 38, period.nextyear, font_style)
    ws.write(row_num, 39, period.nextyear, font_style)
    ws.write(row_num, 40, period.nextyear, font_style)
    ws.write(row_num, 41, period.nextyear, font_style)
    ws.write(row_num, 42, period.nextyear, font_style)

    row_num += 1

    # write column headers in sheet
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()

    # newEmployee = NewEmployee.objects.all()
    for i in range(len(employee)):
        row_num = row_num + 1
        ws.write(row_num, 0, str(employee[i].id), font_style)
        ws.write(row_num, 1, employee[i].erpnr, font_style)
        ws.write(row_num, 2, employee[i].employee, font_style)
        ws.write(row_num, 3, employee[i].type, font_style)
        ws.write(row_num, 4, employee[i].name, font_style)
        ws.write(row_num, 5, employee[i].firstname, font_style)
        ws.write(row_num, 6, employee[i].gendertype, font_style)
        ws.write(row_num, 7, employee[i].gender, font_style)
        ws.write(row_num, 8, employee[i].department, font_style)
        ws.write(row_num, 9, employee[i].entrydate, font_style)
        ws.write(row_num, 10, employee[i].exitdate, font_style)
        ws.write(row_num, 11, employee[i].yearlysalary, font_style)
        ws.write(row_num, 12, employee[i].salary13e, font_style)
        ws.write(row_num, 13, employee[i].monthlyLLPemployee, font_style)
        ws.write(row_num, 14, employee[i].monthlyLLPcompany, font_style)
        ws.write(row_num, 15, employee[i].contractrate, font_style)
        ws.write(row_num, 16, actualyearlist[i].jan, font_style)
        ws.write(row_num, 17, actualyearlist[i].feb, font_style)
        ws.write(row_num, 18, actualyearlist[i].mar, font_style)
        ws.write(row_num, 19, actualyearlist[i].apr, font_style)
        ws.write(row_num, 20, actualyearlist[i].may, font_style)
        ws.write(row_num, 21, actualyearlist[i].jun, font_style)
        ws.write(row_num, 22, actualyearlist[i].jul, font_style)
        ws.write(row_num, 23, actualyearlist[i].aug, font_style)
        ws.write(row_num, 24, actualyearlist[i].sep, font_style)
        ws.write(row_num, 25, actualyearlist[i].oct, font_style)
        ws.write(row_num, 26, actualyearlist[i].nov, font_style)
        ws.write(row_num, 27, actualyearlist[i].dec, font_style)
        ws.write(row_num, 28, actualyearlist[i].avgFTEactual, font_style)
        ws.write(row_num, 29, actualyearlist[i].avgFTEfullyear, font_style)
        ws.write(row_num, 30, predictedyearlist[i].feb, font_style)
        ws.write(row_num, 31, predictedyearlist[i].mar, font_style)
        ws.write(row_num, 32, predictedyearlist[i].apr, font_style)
        ws.write(row_num, 33, predictedyearlist[i].may, font_style)
        ws.write(row_num, 34, predictedyearlist[i].jan, font_style)
        ws.write(row_num, 35, predictedyearlist[i].jun, font_style)
        ws.write(row_num, 36, predictedyearlist[i].jul, font_style)
        ws.write(row_num, 37, predictedyearlist[i].aug, font_style)
        ws.write(row_num, 38, predictedyearlist[i].sep, font_style)
        ws.write(row_num, 39, predictedyearlist[i].oct, font_style)
        ws.write(row_num, 40, predictedyearlist[i].nov, font_style)
        ws.write(row_num, 41, predictedyearlist[i].dec, font_style)
        ws.write(row_num, 42, predictedyearlist[i].avgFTEfullyear, font_style)

    for i in range(len(newemployee)):
        row_num = row_num + 1
        ws.write(row_num, 0, newemployee[i].newid, font_style)
        ws.write(row_num, 1, newemployee[i].erpnr, font_style)
        ws.write(row_num, 2, newemployee[i].employee, font_style)
        ws.write(row_num, 3, newemployee[i].type, font_style)
        ws.write(row_num, 4, newemployee[i].name, font_style)
        ws.write(row_num, 5, newemployee[i].firstname, font_style)
        ws.write(row_num, 6, newemployee[i].gendertype, font_style)
        ws.write(row_num, 7, newemployee[i].gender, font_style)
        ws.write(row_num, 8, newemployee[i].department, font_style)
        ws.write(row_num, 9, newemployee[i].entrydate, font_style)
        ws.write(row_num, 10, newemployee[i].exitdate, font_style)
        ws.write(row_num, 11, newemployee[i].yearlysalary, font_style)
        ws.write(row_num, 12, newemployee[i].salary13e, font_style)
        ws.write(row_num, 13, newemployee[i].monthlyLLPemployee, font_style)
        ws.write(row_num, 14, newemployee[i].monthlyLLPcompany, font_style)
        ws.write(row_num, 15, newemployee[i].contractrate, font_style)
        ws.write(row_num, 16, newactualyearlist[i].jan, font_style)
        ws.write(row_num, 17, newactualyearlist[i].feb, font_style)
        ws.write(row_num, 18, newactualyearlist[i].mar, font_style)
        ws.write(row_num, 19, newactualyearlist[i].apr, font_style)
        ws.write(row_num, 20, newactualyearlist[i].may, font_style)
        ws.write(row_num, 21, newactualyearlist[i].jun, font_style)
        ws.write(row_num, 22, newactualyearlist[i].jul, font_style)
        ws.write(row_num, 23, newactualyearlist[i].aug, font_style)
        ws.write(row_num, 24, newactualyearlist[i].sep, font_style)
        ws.write(row_num, 25, newactualyearlist[i].oct, font_style)
        ws.write(row_num, 26, newactualyearlist[i].nov, font_style)
        ws.write(row_num, 27, newactualyearlist[i].dec, font_style)
        ws.write(row_num, 28, newactualyearlist[i].avgFTEactual, font_style)
        ws.write(row_num, 29, newactualyearlist[i].avgFTEfullyear, font_style)
        ws.write(row_num, 30, newpredictedyearlist[i].feb, font_style)
        ws.write(row_num, 31, newpredictedyearlist[i].mar, font_style)
        ws.write(row_num, 32, newpredictedyearlist[i].apr, font_style)
        ws.write(row_num, 33, newpredictedyearlist[i].may, font_style)
        ws.write(row_num, 34, newpredictedyearlist[i].jan, font_style)
        ws.write(row_num, 35, newpredictedyearlist[i].jun, font_style)
        ws.write(row_num, 36, newpredictedyearlist[i].jul, font_style)
        ws.write(row_num, 37, newpredictedyearlist[i].aug, font_style)
        ws.write(row_num, 38, newpredictedyearlist[i].sep, font_style)
        ws.write(row_num, 39, newpredictedyearlist[i].oct, font_style)
        ws.write(row_num, 40, newpredictedyearlist[i].nov, font_style)
        ws.write(row_num, 41, newpredictedyearlist[i].dec, font_style)
        ws.write(
            row_num, 42, newpredictedyearlist[i].avgFTEfullyear, font_style)
    wb.save(response)
    return response
