from django.contrib import admin

from resources.views import period
from .models import *

admin.site.register(Employee)
admin.site.register(ActualYear)
admin.site.register(PredictedYear)
admin.site.register(Period)
admin.site.register(NewEmployee)
