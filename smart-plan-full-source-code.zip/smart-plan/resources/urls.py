from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.excel_upload),
    path('del/', views.delete),
    path('period/', views.period, name='period'),
    path('planning/', views.planning, name='planning'),
    path('download/', views.download_excel_template, name='download'),
    path('exceldownload/', views.download_excel_data, name='exceldownload'),
    path('api/show/employees/', views.api_show_employees),
    path('api/add/employee/', views.api_add_employee),
    path('api/update/employee/', views.api_update_employee),
    path('api/update/new/employees/', views.api_update_new_employess),
    path('api/planning/showtable/', views.api_planning),
    path('api/update/planning/', views.api_update_planning),
    path('api/update/period/', views.api_update_period),
    path('api/show/actualyear/', views.api_show_actualyear_table),
    path('api/show/predictedyear/', views.api_show_predictedyear_table),
    path('api/delete/employee/', views.api_delete_employee),
]
