
from rest_framework import serializers
from .models import *


class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'


class ActualYearSerializer(serializers.ModelSerializer):
    class Meta:
        model = ActualYear
        fields = '__all__'


class PredictedYearSerializer(serializers.ModelSerializer):
    class Meta:
        model = PredictedYear
        fields = '__all__'


class NewEmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewEmployee
        fields = '__all__'


class PeriodSerializer(serializers.ModelSerializer):
    class Meta:
        model = Period
        fields = '__all__'
